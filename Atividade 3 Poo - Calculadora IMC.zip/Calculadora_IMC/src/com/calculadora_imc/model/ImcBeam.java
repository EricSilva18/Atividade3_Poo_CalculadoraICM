package com.calculadora_imc.model;

import java.text.DecimalFormat;

public class ImcBeam {

    private float peso;
    private float altura;

    public ImcBeam() {
    }

    public ImcBeam(String peso, String altura) {
        setPeso(peso);
        setAltura(altura);
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public void setPeso(String peso) {
        this.peso = (peso.matches("[0-9.]+") == false ? 0f : parseFloat(peso));
    }

    private float parseFloat(String value) {
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return 0f;
        }
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public void setAltura(String altura) {
        this.altura = (altura.matches("[0-9.]+") == false ? 0f : parseFloat(altura));
    }

    public String getResult() {
        if (altura == 0f) {
            return "Resposta Inválida";
        }

        float result = peso / (altura * altura);  // Corrigido o cálculo do IMC
        if (Float.isNaN(result)) {
            return "Resposta Inválida";
        }

        String situacao;
        if (result < 17) {
            situacao = "Muito abaixo do peso";
        } else if (result >= 17 && result <= 18.49) {
            situacao = "Abaixo do peso";
        } else if (result >= 18.50 && result <= 24.99) {
            situacao = "Peso normal";
        } else if (result >= 25 && result <= 29.99) {
            situacao = "Acima do peso";
        } else if (result >= 30 && result <= 34.99) {
            situacao = "Obesidade I";
        } else if (result >= 35 && result <= 39.99) {
            situacao = "Obesidade II (severa)";
        } else {
            situacao = "Obesidade III (mórbida)";
        }

        return "IMC: " + new DecimalFormat("#.##").format(result) + " - " + situacao;
    }

    @Override
    public String toString() {
        return "ImcBeam [peso=" + peso + ", altura=" + altura + ", getResult()=" + getResult() + "]";
    }
}
