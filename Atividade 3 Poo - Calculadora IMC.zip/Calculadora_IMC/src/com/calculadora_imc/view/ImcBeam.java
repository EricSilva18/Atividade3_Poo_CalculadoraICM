package com.calculadora_imc.view;

public class ImcBeam {

}
